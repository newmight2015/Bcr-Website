<?php
// Where will you get the forms' results? , just change default email , to your email
define("WEBMASTER_EMAIL", 'bitcreditscc@gmail.com');
?>